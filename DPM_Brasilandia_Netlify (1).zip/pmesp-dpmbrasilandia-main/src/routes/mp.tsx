import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";

export const Route = createFileRoute("/mp")({
  head: () => ({
    meta: [
      { title: "Ministério Público — Corregedoria" },
      {
        name: "description",
        content:
          "Área de consulta do Ministério Público. Cadastro imediato; o acesso a cada processo é concedido pela Corregedoria.",
      },
    ],
  }),
  component: MpPage,
});

type Mode = "login" | "signup" | "forgot";

function MpPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");
  const [nome, setNome] = useState("");
  const [matricula, setMatricula] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      const { data: prof } = await supabase
        .from("profiles")
        .select("status")
        .eq("id", data.user.id)
        .maybeSingle();
      if (prof?.status === "ativo") {
        navigate({ to: "/mp-processos" });
      } else {
        navigate({ to: "/pendente" });
      }
    })();
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setInfo("E-mail enviado. Verifique sua caixa de entrada (e spam).");
        setMode("login");
      } else if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const { data: userData } = await supabase.auth.getUser();
        const { data: prof } = await supabase
          .from("profiles")
          .select("status")
          .eq("id", userData.user!.id)
          .maybeSingle();
        if (prof?.status === "ativo") {
          navigate({ to: "/mp-processos" });
        } else {
          navigate({ to: "/pendente" });
        }
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/mp`,
            data: { tipo: "mp", nome, matricula },
          },
        });
        if (error) throw error;
        // Não faz login automático — cadastro exige aprovação do Corregedor-Geral.
        await supabase.auth.signOut();
        setInfo(
          "Cadastro enviado. Seu acesso será liberado somente após aprovação do Corregedor-Geral. Você poderá entrar assim que a aprovação for concedida.",
        );
        setMode("login");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro.";
      setError(traduzir(msg));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen">
      <Header />
      <div className="mx-auto grid max-w-md gap-6 px-4 py-16">
        <div>
          <div className="eyebrow">Ministério Público</div>
          <h1 className="mt-2 font-serif text-3xl">
            {mode === "login" ? "Entrar" : mode === "signup" ? "Cadastre-se" : "Recuperar senha"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {mode === "forgot"
              ? "Digite o e-mail cadastrado. Enviaremos as instruções."
              : "Área de consulta. Cadastro imediato — o acesso a cada processo é concedido pela Corregedoria, um a um, apenas para leitura."}
          </p>
        </div>
        <form onSubmit={submit} className="surface grid gap-4 p-6">
          {mode === "signup" && (
            <>
              <Field label="Nome">
                <input
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="input"
                />
              </Field>
              <Field label="Matrícula / Identificação funcional">
                <input
                  value={matricula}
                  onChange={(e) => setMatricula(e.target.value)}
                  className="input"
                />
              </Field>
            </>
          )}
          <Field label="E-mail">
            <input
              type="email"
              required
              placeholder="exemplo@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input"
            />
          </Field>
          {mode !== "forgot" && (
            <Field label="Senha">
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input"
              />
            </Field>
          )}

          {mode === "login" && (
            <div className="-mt-2 flex justify-end">
              <button
                type="button"
                onClick={() => { setMode("forgot"); setError(null); setInfo(null); }}
                className="text-xs text-muted-foreground transition-colors hover:text-primary hover:underline"
              >
                Esqueceu a senha?
              </button>
            </div>
          )}

          {error && (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive-foreground">
              {error}
            </div>
          )}
          {info && (
            <div className="rounded-md border border-primary/40 bg-primary/10 p-3 text-xs">
              {info}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="rounded-md bg-primary py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-60"
          >
            {loading ? "Aguarde..." : mode === "login" ? "Entrar" : mode === "signup" ? "Cadastrar" : "Enviar instruções"}
          </button>

          {mode === "forgot" ? (
            <button
              type="button"
              onClick={() => { setMode("login"); setError(null); setInfo(null); }}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              ← Voltar para login
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setMode(mode === "login" ? "signup" : "login");
                setError(null);
                setInfo(null);
              }}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              {mode === "login" ? "Não tem conta? Cadastrar" : "Já tenho conta. Entrar"}
            </button>
          )}
        </form>
        <Link to="/" className="text-center text-xs text-muted-foreground hover:text-foreground">
          ← Voltar ao início
        </Link>
      </div>
      <style>{`.input{background:var(--input);border:1px solid var(--border);border-radius:6px;padding:.55rem .7rem;font-size:.9rem;color:var(--foreground);width:100%}`}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function traduzir(msg: string): string {
  if (/invalid.*credentials/i.test(msg)) return "E-mail ou senha inválidos.";
  if (/already registered/i.test(msg)) return "Este e-mail já está cadastrado.";
  if (/password/i.test(msg) && /short|6/i.test(msg)) return "Senha muito curta (mínimo 6 caracteres).";
  return msg;
}
